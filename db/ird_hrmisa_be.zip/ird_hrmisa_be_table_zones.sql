
-- --------------------------------------------------------

--
-- Table structure for table `zones`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
-- Last check: Aug 01, 2026 at 12:19 AM
--

DROP TABLE IF EXISTS `zones`;
CREATE TABLE `zones` (
  `ZID` int(11) NOT NULL,
  `ZName` varchar(100) DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `zones`:
--

--
-- Dumping data for table `zones`
--

INSERT INTO `zones` (`ZID`, `ZName`) VALUES
(1, 'North Zone'),
(2, 'South Zone'),
(10, NULL);
