
-- --------------------------------------------------------

--
-- Table structure for table `course_mandatory`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
-- Last check: Aug 01, 2026 at 12:19 AM
--

DROP TABLE IF EXISTS `course_mandatory`;
CREATE TABLE `course_mandatory` (
  `CourID` int(11) NOT NULL,
  `Cour_Desig_ID` int(11) NOT NULL,
  `CourseID` int(11) DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `course_mandatory`:
--   `Cour_Desig_ID`
--       `designations` -> `DID`
--   `CourseID`
--       `courses_list` -> `CourID`
--

--
-- Dumping data for table `course_mandatory`
--

INSERT INTO `course_mandatory` (`CourID`, `Cour_Desig_ID`, `CourseID`) VALUES
(1, 108, 1),
(6, 5, 21),
(7, 4, 21),
(8, 112, 20);
