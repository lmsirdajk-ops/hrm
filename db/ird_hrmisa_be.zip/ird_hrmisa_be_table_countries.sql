
-- --------------------------------------------------------

--
-- Table structure for table `countries`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
-- Last check: Aug 01, 2026 at 12:19 AM
--

DROP TABLE IF EXISTS `countries`;
CREATE TABLE `countries` (
  `CoID` int(11) NOT NULL,
  `CoName` varchar(60) DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `countries`:
--

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`CoID`, `CoName`) VALUES
(1, 'Azad Kashmir'),
(2, 'Pakistan'),
(3, 'Saudi Arabia'),
(4, 'China'),
(5, 'U.S.A'),
(6, 'United Kingdom'),
(11, 'United Arab Emirates');
