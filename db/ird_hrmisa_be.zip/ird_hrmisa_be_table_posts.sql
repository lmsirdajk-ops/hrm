
-- --------------------------------------------------------

--
-- Table structure for table `posts`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
-- Last check: Aug 01, 2026 at 12:19 AM
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `PID` int(11) NOT NULL,
  `P_CirOff` int(11) DEFAULT NULL,
  `P_DesigID` int(11) DEFAULT NULL,
  `P_Vacant` int(11) DEFAULT 0,
  `P_Filled` int(11) DEFAULT 0
) ;

--
-- RELATIONSHIPS FOR TABLE `posts`:
--   `P_CirOff`
--       `circlesoffices` -> `COID`
--   `P_DesigID`
--       `designations` -> `DID`
--

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`PID`, `P_CirOff`, `P_DesigID`, `P_Vacant`, `P_Filled`) VALUES
(1, 1, 1, 0, 1);
