
-- --------------------------------------------------------

--
-- Table structure for table `allowhba`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
-- Last check: Aug 01, 2026 at 12:19 AM
--

DROP TABLE IF EXISTS `allowhba`;
CREATE TABLE `allowhba` (
  `HBAID` int(11) NOT NULL,
  `HBAEid` int(11) DEFAULT NULL,
  `HBACount` int(11) DEFAULT NULL,
  `HBAAppDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `HBADocSub` tinyint(1) DEFAULT 0,
  `HBAStatus` int(11) DEFAULT NULL,
  `HBANotiLtrNo` varchar(150) DEFAULT NULL,
  `HBANotiLtrDate` timestamp NOT NULL DEFAULT current_timestamp()
) ;

--
-- RELATIONSHIPS FOR TABLE `allowhba`:
--   `HBAEid`
--       `employees` -> `eid`
--

--
-- Dumping data for table `allowhba`
--

INSERT INTO `allowhba` (`HBAID`, `HBAEid`, `HBACount`, `HBAAppDate`, `HBADocSub`, `HBAStatus`, `HBANotiLtrNo`, `HBANotiLtrDate`) VALUES
(3, 252, 1, '2026-01-12 10:36:37', -1, 1, NULL, '2026-07-14 17:07:24'),
(4, 252, 2, '2026-01-12 11:22:32', -1, NULL, NULL, '2026-01-11 19:00:00');
