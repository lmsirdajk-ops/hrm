
-- --------------------------------------------------------

--
-- Table structure for table `userroletbl`
--
-- Creation: Aug 02, 2026 at 12:43 AM
--

DROP TABLE IF EXISTS `userroletbl`;
CREATE TABLE `userroletbl` (
  `UserRoleId` int(11) NOT NULL,
  `Role` varchar(255) DEFAULT NULL,
  `UpdateDate` datetime DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `userroletbl`:
--

--
-- Dumping data for table `userroletbl`
--

INSERT INTO `userroletbl` (`UserRoleId`, `Role`, `UpdateDate`) VALUES
(1, 'User (New Entry Only)', NULL),
(2, 'Admin (User/Sys. Management)', NULL),
(3, 'Manager (Modify Data)', NULL),
(4, 'Manager All (Verification Rights)', '2024-08-21 20:30:26'),
(6, 'Manager & Admin (Full Rights)', '2025-02-06 00:00:00');
