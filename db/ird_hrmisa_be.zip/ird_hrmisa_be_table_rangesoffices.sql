
-- --------------------------------------------------------

--
-- Table structure for table `rangesoffices`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
-- Last check: Aug 01, 2026 at 12:19 AM
--

DROP TABLE IF EXISTS `rangesoffices`;
CREATE TABLE `rangesoffices` (
  `RID` int(11) NOT NULL,
  `RName` varchar(255) DEFAULT NULL,
  `Zid` int(11) DEFAULT 1,
  `RSortOrd` int(11) DEFAULT 0
) ;

--
-- RELATIONSHIPS FOR TABLE `rangesoffices`:
--   `Zid`
--       `zones` -> `ZID`
--

--
-- Dumping data for table `rangesoffices`
--

INSERT INTO `rangesoffices` (`RID`, `RName`, `Zid`, `RSortOrd`) VALUES
(1, 'Range-II', 1, 5),
(2, 'Range-IV', 1, 7),
(3, 'Range-I', 2, 4),
(4, 'Range-III', 2, 6),
(29, NULL, NULL, 1),
(30, NULL, 1, 2),
(31, NULL, 2, 3);
