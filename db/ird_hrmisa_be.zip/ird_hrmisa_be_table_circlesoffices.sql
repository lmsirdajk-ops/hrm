
-- --------------------------------------------------------

--
-- Table structure for table `circlesoffices`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
-- Last check: Aug 01, 2026 at 12:07 AM
--

DROP TABLE IF EXISTS `circlesoffices`;
CREATE TABLE `circlesoffices` (
  `COID` int(11) NOT NULL,
  `COName` varchar(60) DEFAULT NULL,
  `COName BM` varchar(255) DEFAULT NULL,
  `CORangID` int(11) DEFAULT NULL,
  `COAdd` varchar(250) DEFAULT 'Nil',
  `COCity` int(11) DEFAULT NULL,
  `COPhLand` varchar(12) DEFAULT NULL,
  `COPhLand2` varchar(12) DEFAULT NULL,
  `COOffCell` varchar(16) DEFAULT NULL,
  `COIncharge` varchar(60) DEFAULT NULL,
  `COInchDesignID` int(11) DEFAULT NULL,
  `COInchCell` varchar(16) DEFAULT NULL,
  `CoInchEmail` varchar(90) DEFAULT NULL,
  `COEmail` varchar(90) DEFAULT NULL,
  `COSortOrd` int(11) DEFAULT 0,
  `COPO` varchar(1) DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `circlesoffices`:
--   `COCity`
--       `cities` -> `CID`
--   `COInchDesignID`
--       `designations` -> `DID`
--   `COIncharge`
--       `employees` -> `eid`
--   `CORangID`
--       `rangesoffices` -> `RID`
--

--
-- Dumping data for table `circlesoffices`
--

INSERT INTO `circlesoffices` (`COID`, `COName`, `COName BM`, `CORangID`, `COAdd`, `COCity`, `COPhLand`, `COPhLand2`, `COOffCell`, `COIncharge`, `COInchDesignID`, `COInchCell`, `CoInchEmail`, `COEmail`, `COSortOrd`, `COPO`) VALUES
(1, 'AJK-CBR Office', 'AJ&K Central Board of Revenue', 29, '\"C\" Block, New PM House, Jalalabad,', 1, NULL, NULL, NULL, 'Chudhary Abdul Rehman', 108, NULL, 'chairmancbr@gmail.com', NULL, 1, '0'),
(3, 'Secretariat IRD', 'Secretariat IRD', 29, '3rd Floor, Block-4, New Secretariat, Muzafferabad.', 1, NULL, NULL, NULL, 'Chudhary Abdul Rehman', 1, '0345-2252536', 'Usman@gmail.com', NULL, 3, '0'),
(4, 'C-01, Business, MZD', 'C-01, Business, MZD', 1, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 8, '1'),
(5, 'C-02, MPR', 'Inland Revenue Circle-02, (Companies) Mirpur', 3, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9, '1'),
(6, 'C-03, Kotli', 'Inland Revenue Circle-03, Kotli', 4, 'Nil', 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, '1'),
(7, 'C-04, Rawalakot', 'Inland Revenue Circle-04, Rawalakot', 2, 'Nil', 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 11, '1'),
(8, 'C-05, Bagh', 'Inland Revenue Circle-05, Bagh', 2, 'Nil', 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 12, '1'),
(9, 'C-06, Salary Circle', 'Inland Revenue Circle-06, (Salary) MZD', 1, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 13, '1'),
(10, 'C-07, Salary Circle', 'Inland Revenue Circle-07 ,(Salary), Mirpur', 3, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 14, '1'),
(11, 'C-08, Bhimber', 'Inland Revenue Circle-08, Bhimber', 4, 'Nil', 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 15, '1'),
(12, 'C-09, Sudhnuti', 'Inland Revenue Circle-09, Sudhnuti', 2, 'Nil', 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 16, '1'),
(13, 'C-10, Professional Circle, MZD', 'Inland Revenue Circle-10 (Professional), MUZAFFARABAD', 1, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 17, '1'),
(14, 'C-11, Business Circle, MPR', 'Inland Revenue Circle-11, (Business), Mirpur', 3, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 18, '1'),
(15, 'C-12, Professional Circle, MPR', 'Inland Revenue Circle-12 (Professional), Mirpur', 3, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 19, '1'),
(16, 'C-13, Dudyal', 'Inland Revenue Circle-13, Dudyal', 3, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20, '1'),
(17, 'C-14, (Companies), MZD', 'Inland Revenue Circle-14 (WHT), MZD', 1, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 21, '1'),
(18, 'C-15, Neelum Valley', 'Inland Revenue Circle-15, Neelum', 1, 'Nil', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 22, '1'),
(19, 'C-16, Chaksawari', 'Inland Revenue Circle-16, Chaksawari', 4, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 23, '1'),
(21, 'CIR (DT/North), Head Office, MZD', 'Commissioner IR (Direct Tax), Muzaffarabad', 30, 'Texation Department, Near Darbar Saheli Sarkar, Muzaffarabad,\r\nAJK (13100).', 1, '05822-921145', NULL, NULL, 'Mr. Basil Siddique', 2, NULL, NULL, NULL, 4, '1'),
(22, 'CIR (PT/South), MPR', 'Commissioner Inland Revenue (Provincial Taxes), Mirpur', 31, 'Srailen Road, New Mirpur City, Azad Jammu and Kashmir (10250)', 2, NULL, NULL, NULL, 'Syed Anser Ali', 2, '0300-2525252', 'anserali@gmail.com', NULL, 5, '1'),
(23, 'Excise Circle, MZD', 'Inland Revenue (P.T), Muzaffarabad', 1, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 7, '1'),
(24, 'Excise Circle, MPR', 'Inland Revenue (P.T), Mirpur', 4, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(26, 'Muzafferabad Circle', NULL, 1, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(27, 'Commissioner IR (Appeals) Office', 'Commissioner Inland Revenue (Appeals), Mirpur', 29, 'Nil', 2, NULL, NULL, NULL, 'Mr. Ishtiaq Ahmed', 2, NULL, NULL, NULL, 6, '1'),
(28, 'Business & Excise Circle, MZD', NULL, 30, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(29, 'Range-I Office', 'Additional Commissioner Inland Revenue Range-I, Mirpur', 3, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 7, '1'),
(30, 'Range-III Office', 'Additional Commissioner Inland Revenue Range-III, Mirpur', 4, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9, '1'),
(31, 'Excise Audit & Preventive Br. MZD', 'CENTRAL EXCISE & SALES TAX AUDIT & PREVENTIVE BRANCH, MUZAFFARABAD', 1, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, '1'),
(32, 'Recovery Circle, MPR', NULL, NULL, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(33, 'Business/Salary MPR', NULL, NULL, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(34, 'Company Circle, MPR', NULL, NULL, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(35, 'Assistant Commissioner', NULL, NULL, 'Islamabad', 8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(36, 'Ligitation Wing', NULL, 29, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(37, 'CIR Office, Mirpur', NULL, 29, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(38, 'Addl Collector, MPR', NULL, 29, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(39, 'Toll Post Bararkot', NULL, 1, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(40, 'Toll Post Kohala', NULL, 1, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(41, 'Toll Post Shaheed Gali', NULL, 1, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(42, 'Range-II Office', 'Additional Commissioner Inland Revenue Range-II, Mirpur', 1, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 8, '1'),
(43, 'IAC Survey', NULL, 30, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(44, 'CIT APPEAL', NULL, 31, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(45, 'WHT Monitoring Cell', NULL, 29, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(46, 'C-14, (WHT), MZD', NULL, 1, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 21, '0'),
(47, 'Collectorate Office', NULL, 31, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(48, 'Preventive Br.', NULL, 30, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(49, 'Range-IV Office', 'Additional Commissioner Inland Revenue Range-IV, Mirpur', 2, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 8, '1'),
(50, 'Departmental Preventive, Mirpur', 'Departmental Preventive, Mirpur', 29, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '1'),
(51, 'Addl Collector E&ST, R-IV, MPR', 'Additional Collector E&ST Range-IV, Mirpur', 2, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '1'),
(52, 'Inland Revenue (PT), MZD', 'Inland Revenue, Excise/ (P.T), MUZAFFARABAD', 29, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '1'),
(53, 'Inland Revenue (PT), Mirpur', 'Inland Revenue, Excise/ (P.T), Mirpur', 29, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '1'),
(55, 'A.A.C', NULL, 30, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(56, 'CIT', NULL, 29, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(57, 'Toll Post Mangla', NULL, 31, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(58, 'Toll Post Ali Baig', NULL, 31, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(59, 'Toll Post Kadhala', NULL, 31, 'Nil', 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(60, 'Toll Post Brarkot', NULL, 30, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(61, 'SA Office', NULL, 31, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(62, 'Range-II Office', NULL, 31, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(63, 'IAC Range', NULL, 30, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(64, 'SHIFTNS', NULL, 30, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(65, 'Excise Ciecle-Mobile Squad', NULL, 1, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(66, 'AJK Council Secretariat', NULL, NULL, 'F-5/2, Islamabad', 8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(67, 'Services & General Administration Department', NULL, 29, 'New Civil Secretariat, Muzaffarabad', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(68, 'Assistant Collector E&ST', NULL, 3, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(69, 'Business/ Company Circle', NULL, 31, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(70, 'Additional CIR Office', NULL, 31, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(71, 'DR Inland Revenue', NULL, 31, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0'),
(72, 'Office of Accountant Member ATIR', NULL, 29, 'Nil', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '1');
