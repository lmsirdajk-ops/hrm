
-- --------------------------------------------------------

--
-- Table structure for table `leavetypes`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
-- Last check: Aug 01, 2026 at 12:19 AM
--

DROP TABLE IF EXISTS `leavetypes`;
CREATE TABLE `leavetypes` (
  `LID` int(11) NOT NULL,
  `LShortName` varchar(30) DEFAULT NULL,
  `LLongName` varchar(100) DEFAULT NULL,
  `Remarks` varchar(255) DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `leavetypes`:
--

--
-- Dumping data for table `leavetypes`
--

INSERT INTO `leavetypes` (`LID`, `LShortName`, `LLongName`, `Remarks`) VALUES
(1, 'C/L', 'Casual Leave', 'Short-term leave taken for unexpected personal reasons or emergencies'),
(2, 'LFP', 'Leave with Full Pay', NULL),
(3, 'Sick Leave', 'Sick Leave (Medical Leave)', 'Used when an employee is ill and requires time off to recover, typically supported by a medical certificate'),
(4, 'Study Leave', 'Educational Leave', 'Leave granted for pursuing further education, often with conditions regarding reimbursement or return to employment.'),
(5, 'Unpaid Leave', NULL, 'Time off without pay when an employee needs to be absent from work for personal reasons and has exhausted other leave options.');
