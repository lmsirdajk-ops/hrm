
--
-- Indexes for dumped tables
--

--
-- Indexes for table `allowhba`
--
ALTER TABLE `allowhba`
  ADD PRIMARY KEY (`HBAID`),
  ADD UNIQUE KEY `HBAEid` (`HBAEid`,`HBACount`);

--
-- Indexes for table `appointposttrans`
--
ALTER TABLE `appointposttrans`
  ADD PRIMARY KEY (`APT_ID`),
  ADD KEY `APT_DesigID` (`APT_DesigID`),
  ADD KEY `APT_NewDesigID` (`APT_NewDesigID`),
  ADD KEY `APT_EMP_ID` (`APT_EMP_ID`),
  ADD KEY `APT_ID` (`APT_ID`);

--
-- Indexes for table `circlesoffices`
--
ALTER TABLE `circlesoffices`
  ADD PRIMARY KEY (`COID`),
  ADD KEY `COInchDesignID` (`COInchDesignID`),
  ADD KEY `CORangID` (`CORangID`),
  ADD KEY `COID` (`COID`);

--
-- Indexes for table `circlesofficesoldnew`
--
ALTER TABLE `circlesofficesoldnew`
  ADD PRIMARY KEY (`COID`),
  ADD KEY `COInchDesignID` (`COInchDesignID`),
  ADD KEY `CORangID` (`CORangID`),
  ADD KEY `COID` (`COID`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`CID`),
  ADD KEY `CID` (`CID`),
  ADD KEY `CoID` (`CoID`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`CoID`),
  ADD KEY `CoID` (`CoID`),
  ADD KEY `CoName` (`CoName`);

--
-- Indexes for table `courses_list`
--
ALTER TABLE `courses_list`
  ADD PRIMARY KEY (`CourID`),
  ADD KEY `CourID` (`CourID`);

--
-- Indexes for table `course_mandatory`
--
ALTER TABLE `course_mandatory`
  ADD PRIMARY KEY (`CourID`),
  ADD KEY `CourseID` (`CourseID`),
  ADD KEY `Cour_Desig_ID` (`Cour_Desig_ID`),
  ADD KEY `CourID` (`CourID`);

--
-- Indexes for table `designations`
--
ALTER TABLE `designations`
  ADD PRIMARY KEY (`DID`),
  ADD KEY `DesigBS` (`DesigBS`),
  ADD KEY `DID` (`DID`);

--
-- Indexes for table `disciplinehistory`
--
ALTER TABLE `disciplinehistory`
  ADD PRIMARY KEY (`DSID`),
  ADD KEY `DS_ReportOffr` (`DS_ReportOffr`),
  ADD KEY `DS_EMP_ID` (`DS_EMP_ID`),
  ADD KEY `DSID` (`DSID`);

--
-- Indexes for table `domiciles`
--
ALTER TABLE `domiciles`
  ADD PRIMARY KEY (`CID`),
  ADD KEY `CID` (`CID`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`eid`),
  ADD KEY `BMSID` (`BMSID`),
  ADD KEY `CNIC` (`CNIC`),
  ADD KEY `eDesigID` (`eDesigID`),
  ADD KEY `eid` (`eid`);

--
-- Indexes for table `empqual`
--
ALTER TABLE `empqual`
  ADD PRIMARY KEY (`EQID`),
  ADD KEY `EQ_EMP_ID` (`EQ_EMP_ID`),
  ADD KEY `EQID` (`EQID`);

--
-- Indexes for table `fbnames`
--
ALTER TABLE `fbnames`
  ADD PRIMARY KEY (`FBNID`),
  ADD KEY `FBNID` (`FBNID`),
  ADD KEY `FBName` (`FBName`);

--
-- Indexes for table `finanbenifitsrecoveries`
--
ALTER TABLE `finanbenifitsrecoveries`
  ADD PRIMARY KEY (`FBRID`),
  ADD KEY `FBRFBID` (`FBRFBID`),
  ADD KEY `FBRID` (`FBRID`);

--
-- Indexes for table `fin_benifits`
--
ALTER TABLE `fin_benifits`
  ADD PRIMARY KEY (`FBID`),
  ADD KEY `FBEID` (`FBEID`),
  ADD KEY `FBID` (`FBID`);

--
-- Indexes for table `leavetypes`
--
ALTER TABLE `leavetypes`
  ADD PRIMARY KEY (`LID`),
  ADD KEY `LID` (`LID`);

--
-- Indexes for table `performance`
--
ALTER TABLE `performance`
  ADD PRIMARY KEY (`PerfID`),
  ADD KEY `PerEmpID` (`PerEmpID`),
  ADD KEY `PerfID` (`PerfID`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`PID`),
  ADD KEY `PID` (`PID`),
  ADD KEY `P_DesigID` (`P_DesigID`);

--
-- Indexes for table `promotupgrade`
--
ALTER TABLE `promotupgrade`
  ADD PRIMARY KEY (`PUID`),
  ADD KEY `PU_EMP_ID` (`PU_EMP_ID`),
  ADD KEY `PU_PromDesigID` (`PU_PromDesigID`),
  ADD KEY `PU_PromDesigIDAs` (`PU_PromDesigIDAs`),
  ADD KEY `PUID` (`PUID`);

--
-- Indexes for table `qualifications`
--
ALTER TABLE `qualifications`
  ADD PRIMARY KEY (`QID`),
  ADD KEY `QID` (`QID`);

--
-- Indexes for table `qual_disciplines`
--
ALTER TABLE `qual_disciplines`
  ADD PRIMARY KEY (`DisID`),
  ADD KEY `DisID` (`DisID`);

--
-- Indexes for table `qual_framework`
--
ALTER TABLE `qual_framework`
  ADD PRIMARY KEY (`QFID`),
  ADD KEY `QFID` (`QFID`);

--
-- Indexes for table `rangesoffices`
--
ALTER TABLE `rangesoffices`
  ADD PRIMARY KEY (`RID`),
  ADD KEY `Zid` (`Zid`),
  ADD KEY `RID` (`RID`);

--
-- Indexes for table `tities`
--
ALTER TABLE `tities`
  ADD PRIMARY KEY (`CID`),
  ADD KEY `CID` (`CID`),
  ADD KEY `CoID` (`CoID`);

--
-- Indexes for table `training`
--
ALTER TABLE `training`
  ADD PRIMARY KEY (`TrainID`),
  ADD KEY `Train_EMP_ID` (`Train_EMP_ID`),
  ADD KEY `TrainID` (`TrainID`);

--
-- Indexes for table `useraccessdatatbl`
--
ALTER TABLE `useraccessdatatbl`
  ADD PRIMARY KEY (`UsrAccID`),
  ADD KEY `UsrAccEID` (`UsrAccUID`),
  ADD KEY `UsrAccID` (`UsrAccID`);

--
-- Indexes for table `userinformationtbl`
--
ALTER TABLE `userinformationtbl`
  ADD PRIMARY KEY (`UID`),
  ADD KEY `StatusId` (`StatusId`),
  ADD KEY `UID` (`UID`),
  ADD KEY `UserRoleId` (`UserRoleId`);

--
-- Indexes for table `userroletbl`
--
ALTER TABLE `userroletbl`
  ADD PRIMARY KEY (`UserRoleId`),
  ADD KEY `UserRoleId` (`UserRoleId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `StatusId` (`StatusId`),
  ADD KEY `UserRoleId` (`UserRoleId`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `zones`
--
ALTER TABLE `zones`
  ADD PRIMARY KEY (`ZID`),
  ADD UNIQUE KEY `ZName` (`ZName`),
  ADD KEY `ZID` (`ZID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `allowhba`
--
ALTER TABLE `allowhba`
  MODIFY `HBAID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `appointposttrans`
--
ALTER TABLE `appointposttrans`
  MODIFY `APT_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `circlesoffices`
--
ALTER TABLE `circlesoffices`
  MODIFY `COID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `circlesofficesoldnew`
--
ALTER TABLE `circlesofficesoldnew`
  MODIFY `COID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `CID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `CoID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `courses_list`
--
ALTER TABLE `courses_list`
  MODIFY `CourID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `course_mandatory`
--
ALTER TABLE `course_mandatory`
  MODIFY `CourID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `designations`
--
ALTER TABLE `designations`
  MODIFY `DID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `disciplinehistory`
--
ALTER TABLE `disciplinehistory`
  MODIFY `DSID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `domiciles`
--
ALTER TABLE `domiciles`
  MODIFY `CID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `eid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `empqual`
--
ALTER TABLE `empqual`
  MODIFY `EQID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fbnames`
--
ALTER TABLE `fbnames`
  MODIFY `FBNID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `finanbenifitsrecoveries`
--
ALTER TABLE `finanbenifitsrecoveries`
  MODIFY `FBRID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fin_benifits`
--
ALTER TABLE `fin_benifits`
  MODIFY `FBID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leavetypes`
--
ALTER TABLE `leavetypes`
  MODIFY `LID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `performance`
--
ALTER TABLE `performance`
  MODIFY `PerfID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `PID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `promotupgrade`
--
ALTER TABLE `promotupgrade`
  MODIFY `PUID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `qualifications`
--
ALTER TABLE `qualifications`
  MODIFY `QID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `qual_disciplines`
--
ALTER TABLE `qual_disciplines`
  MODIFY `DisID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `qual_framework`
--
ALTER TABLE `qual_framework`
  MODIFY `QFID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rangesoffices`
--
ALTER TABLE `rangesoffices`
  MODIFY `RID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tities`
--
ALTER TABLE `tities`
  MODIFY `CID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `training`
--
ALTER TABLE `training`
  MODIFY `TrainID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `useraccessdatatbl`
--
ALTER TABLE `useraccessdatatbl`
  MODIFY `UsrAccID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `userinformationtbl`
--
ALTER TABLE `userinformationtbl`
  MODIFY `UID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `zones`
--
ALTER TABLE `zones`
  MODIFY `ZID` int(11) NOT NULL AUTO_INCREMENT;


--
-- Metadata
--
USE phpmyadmin;

--
-- Metadata for table allowhba
--

--
-- Metadata for table appointposttrans
--

--
-- Metadata for table circlesoffices
--

--
-- Metadata for table circlesofficesoldnew
--

--
-- Metadata for table cities
--

--
-- Metadata for table countries
--

--
-- Metadata for table courses_list
--

--
-- Metadata for table course_mandatory
--

--
-- Metadata for table designations
--

--
-- Metadata for table disciplinehistory
--

--
-- Metadata for table domiciles
--

--
-- Metadata for table employees
--

--
-- Metadata for table empqual
--

--
-- Metadata for table fbnames
--

--
-- Metadata for table finanbenifitsrecoveries
--

--
-- Metadata for table fin_benifits
--

--
-- Metadata for table leavetypes
--

--
-- Metadata for table performance
--

--
-- Metadata for table posts
--

--
-- Metadata for table promotupgrade
--

--
-- Metadata for table qualifications
--

--
-- Metadata for table qual_disciplines
--

--
-- Metadata for table qual_framework
--

--
-- Metadata for table rangesoffices
--

--
-- Metadata for table tities
--

--
-- Metadata for table training
--

--
-- Metadata for table useraccessdatatbl
--

--
-- Metadata for table userinformationtbl
--

--
-- Metadata for table userroletbl
--

--
-- Metadata for table users
--

--
-- Metadata for table zones
--

--
-- Metadata for database ird_hrmisa_be
--

--
-- Dumping data for table `pma__relation`
--

INSERT INTO `pma__relation` (`master_db`, `master_table`, `master_field`, `foreign_db`, `foreign_table`, `foreign_field`) VALUES
('ird_hrmisa_be', 'allowhba', 'HBAEid', 'ird_hrmisa_be', 'employees', 'eid'),
('ird_hrmisa_be', 'appointposttrans', 'APT_CircOffi', 'ird_hrmisa_be', 'circlesoffices', 'COID'),
('ird_hrmisa_be', 'appointposttrans', 'APT_DesigID', 'ird_hrmisa_be', 'designations', 'DID'),
('ird_hrmisa_be', 'appointposttrans', 'APT_EMP_ID', 'ird_hrmisa_be', 'employees', 'eid'),
('ird_hrmisa_be', 'appointposttrans', 'APT_NewCircOffi', 'ird_hrmisa_be', 'circlesoffices', 'COID'),
('ird_hrmisa_be', 'appointposttrans', 'APT_NewDesigID', 'ird_hrmisa_be', 'designations', 'DID'),
('ird_hrmisa_be', 'circlesoffices', 'COCity', 'ird_hrmisa_be', 'cities', 'CID'),
('ird_hrmisa_be', 'circlesoffices', 'COInchDesignID', 'ird_hrmisa_be', 'designations', 'DID'),
('ird_hrmisa_be', 'circlesoffices', 'COIncharge', 'ird_hrmisa_be', 'employees', 'eid'),
('ird_hrmisa_be', 'circlesoffices', 'CORangID', 'ird_hrmisa_be', 'rangesoffices', 'RID'),
('ird_hrmisa_be', 'cities', 'CoID', 'ird_hrmisa_be', 'countries', 'CoID'),
('ird_hrmisa_be', 'course_mandatory', 'Cour_Desig_ID', 'ird_hrmisa_be', 'designations', 'DID'),
('ird_hrmisa_be', 'course_mandatory', 'CourseID', 'ird_hrmisa_be', 'courses_list', 'CourID'),
('ird_hrmisa_be', 'disciplinehistory', 'DS_EMP_ID', 'ird_hrmisa_be', 'employees', 'eid'),
('ird_hrmisa_be', 'disciplinehistory', 'DS_ReportOffr', 'ird_hrmisa_be', 'employees', 'eid'),
('ird_hrmisa_be', 'domiciles', 'CoName', 'ird_hrmisa_be', 'countries', 'CoID'),
('ird_hrmisa_be', 'employees', 'Permanent_Add_City', 'ird_hrmisa_be', 'cities', 'CID'),
('ird_hrmisa_be', 'employees', 'Present_Add_City', 'ird_hrmisa_be', 'cities', 'CID'),
('ird_hrmisa_be', 'employees', 'eCircOffi', 'ird_hrmisa_be', 'circlesoffices', 'COID'),
('ird_hrmisa_be', 'employees', 'eCircOffiWork', 'ird_hrmisa_be', 'circlesoffices', 'COID'),
('ird_hrmisa_be', 'employees', 'eDesigID', 'ird_hrmisa_be', 'designations', 'DID'),
('ird_hrmisa_be', 'empqual', 'EQ_EMP_ID', 'ird_hrmisa_be', 'employees', 'eid'),
('ird_hrmisa_be', 'empqual', 'Emp_Qual', 'ird_hrmisa_be', 'qualifications', 'QID'),
('ird_hrmisa_be', 'fin_benifits', 'FBEID', 'ird_hrmisa_be', 'employees', 'eid'),
('ird_hrmisa_be', 'finanbenifitsrecoveries', 'FBRFBID', 'ird_hrmisa_be', 'fin_benifits', 'FBID'),
('ird_hrmisa_be', 'performance', 'PerEmpID', 'ird_hrmisa_be', 'employees', 'eid'),
('ird_hrmisa_be', 'posts', 'P_CirOff', 'ird_hrmisa_be', 'circlesoffices', 'COID'),
('ird_hrmisa_be', 'posts', 'P_DesigID', 'ird_hrmisa_be', 'designations', 'DID'),
('ird_hrmisa_be', 'promotupgrade', 'PU_EMP_ID', 'ird_hrmisa_be', 'employees', 'eid'),
('ird_hrmisa_be', 'promotupgrade', 'PU_PromDesigID', 'ird_hrmisa_be', 'designations', 'DID'),
('ird_hrmisa_be', 'promotupgrade', 'PU_PromDesigIDAs', 'ird_hrmisa_be', 'designations', 'DID'),
('ird_hrmisa_be', 'qualifications', 'Q_Disp', 'ird_hrmisa_be', 'qual_disciplines', 'DisID'),
('ird_hrmisa_be', 'qualifications', 'Q_Level', 'ird_hrmisa_be', 'qual_framework', 'QFID'),
('ird_hrmisa_be', 'rangesoffices', 'Zid', 'ird_hrmisa_be', 'zones', 'ZID'),
('ird_hrmisa_be', 'training', 'Country', 'ird_hrmisa_be', 'countries', 'CoID'),
('ird_hrmisa_be', 'training', 'Course Title', 'ird_hrmisa_be', 'courses_list', 'CourID'),
('ird_hrmisa_be', 'training', 'Train_EMP_ID', 'ird_hrmisa_be', 'employees', 'eid'),
('ird_hrmisa_be', 'useraccessdatatbl', 'UsrAccArea', 'ird_hrmisa_be', 'circlesoffices', 'COID'),
('ird_hrmisa_be', 'useraccessdatatbl', 'UsrAccUID', 'ird_hrmisa_be', 'users', 'id'),
('ird_hrmisa_be', 'userinformationtbl', 'CircOffi', 'ird_hrmisa_be', 'circlesoffices', 'COID'),
('ird_hrmisa_be', 'userinformationtbl', 'Position', 'ird_hrmisa_be', 'designations', 'DID'),
('ird_hrmisa_be', 'userinformationtbl', 'UserRoleId', 'ird_hrmisa_be', 'userroletbl', 'UserRoleId');
