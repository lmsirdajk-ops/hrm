
-- --------------------------------------------------------

--
-- Table structure for table `fbnames`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
-- Last check: Aug 01, 2026 at 12:19 AM
--

DROP TABLE IF EXISTS `fbnames`;
CREATE TABLE `fbnames` (
  `FBNID` int(11) NOT NULL,
  `FBName` varchar(20) DEFAULT NULL,
  `FBFName` varchar(255) DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `fbnames`:
--

--
-- Dumping data for table `fbnames`
--

INSERT INTO `fbnames` (`FBNID`, `FBName`, `FBFName`) VALUES
(2, 'Honorarium', 'Honorarium-2025'),
(3, 'MCA-1', 'Motor Cycle Advance (First)'),
(4, 'Cycle Adv-1', 'Cycle Advance (First)'),
(5, 'GP Fund', 'General Provident Fund'),
(6, 'Cash Rwd.', 'Cash Reward'),
(8, 'CA-2', 'Car Advance (Second)'),
(9, 'MCA-2', 'Motor Cycle Advance (Second)'),
(10, 'Cycle Adv-2', 'Cycle Advance (Second)');
