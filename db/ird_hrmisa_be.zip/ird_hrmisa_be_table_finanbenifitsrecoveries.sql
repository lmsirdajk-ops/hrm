
-- --------------------------------------------------------

--
-- Table structure for table `finanbenifitsrecoveries`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
--

DROP TABLE IF EXISTS `finanbenifitsrecoveries`;
CREATE TABLE `finanbenifitsrecoveries` (
  `FBRID` int(11) NOT NULL,
  `FBRFBID` int(11) DEFAULT NULL,
  `FBRAmount` decimal(19,4) DEFAULT 0.0000,
  `FBRAmountDt` datetime DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `finanbenifitsrecoveries`:
--   `FBRFBID`
--       `fin_benifits` -> `FBID`
--
