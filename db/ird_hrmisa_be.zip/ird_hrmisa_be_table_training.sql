
-- --------------------------------------------------------

--
-- Table structure for table `training`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
-- Last check: Aug 01, 2026 at 12:19 AM
--

DROP TABLE IF EXISTS `training`;
CREATE TABLE `training` (
  `TrainID` int(11) NOT NULL,
  `Train_EMP_ID` int(11) NOT NULL,
  `Course Title` int(11) DEFAULT NULL,
  `Location` varchar(50) DEFAULT NULL,
  `Country` int(11) DEFAULT NULL,
  `Start Date` datetime DEFAULT NULL,
  `End Date` datetime DEFAULT NULL,
  `Duration` varchar(50) DEFAULT NULL,
  `CourseStatus` varchar(1) DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `training`:
--   `Country`
--       `countries` -> `CoID`
--   `Course Title`
--       `courses_list` -> `CourID`
--   `Train_EMP_ID`
--       `employees` -> `eid`
--

--
-- Dumping data for table `training`
--

INSERT INTO `training` (`TrainID`, `Train_EMP_ID`, `Course Title`, `Location`, `Country`, `Start Date`, `End Date`, `Duration`, `CourseStatus`) VALUES
(1, 64, 11, 'Special Edu. & Social Welfare Div, Islamabad', 2, '1995-09-19 00:00:00', '1995-11-05 00:00:00', NULL, NULL),
(2, 64, 12, 'Zeeshan Typing Coll. Islamabad', 2, '1997-05-01 00:00:00', '1997-11-02 00:00:00', NULL, NULL),
(3, 47, 13, 'Punjab Univ. Lahore', 2, '2017-01-01 00:00:00', '2018-01-01 00:00:00', NULL, NULL),
(4, 48, 14, 'Islamabad', 2, '2008-03-03 00:00:00', '2008-03-08 00:00:00', NULL, NULL),
(5, 43, 15, 'DG Custom Excise', 2, '2000-10-16 00:00:00', '2000-10-19 00:00:00', NULL, NULL),
(6, 43, 17, 'Skill Development', 2, '2004-04-08 00:00:00', '2004-05-08 00:00:00', NULL, NULL),
(7, 43, 18, 'Skill Development', 2, '2004-04-08 00:00:00', '2004-05-08 00:00:00', NULL, NULL),
(8, 345, 19, 'Civil Services Academy Lahore', 2, '2011-01-13 00:00:00', '2011-06-29 00:00:00', NULL, NULL),
(9, 345, 20, 'DOT, FBR, Lahore', 2, '2011-06-30 00:00:00', '2012-01-14 00:00:00', NULL, NULL),
(10, 345, 21, 'NIM, Lahore', 2, '2021-02-01 00:00:00', '2021-04-09 00:00:00', NULL, NULL),
(11, 52, 13, 'PULC, Lahore', 2, '2016-03-10 00:00:00', '2017-02-16 00:00:00', NULL, NULL),
(12, 252, 11, 'Moon Creation School of IT Muzaffarabad', 1, NULL, NULL, NULL, NULL),
(13, 320, 22, 'Federal Civil Defence', 1, '2008-09-15 00:00:00', '2008-09-27 00:00:00', NULL, NULL),
(14, 320, 23, 'NRSP', 1, '2006-04-10 00:00:00', '2006-05-10 00:00:00', NULL, NULL),
(15, 320, 24, 'Islamic Relief Pakistan', 1, '2008-08-26 00:00:00', '2008-09-25 00:00:00', NULL, NULL),
(16, 230, 11, 'AJK IT Board', 1, '2009-07-07 00:00:00', '2009-09-07 00:00:00', NULL, NULL),
(17, 230, 25, 'NAVTTC', 1, '2024-06-01 00:00:00', '2024-12-01 00:00:00', NULL, NULL),
(18, 151, 26, 'Micro Tech Computer Center Rawalpindi', 2, '2008-01-01 00:00:00', '2008-03-31 00:00:00', NULL, NULL),
(19, 20, 27, 'AJ&K Civil Defence', 1, '1996-04-01 00:00:00', '1996-05-02 00:00:00', NULL, NULL),
(20, 20, 14, 'Pakistan CBR', 1, '2008-03-03 00:00:00', '2008-03-08 00:00:00', NULL, NULL),
(21, 20, 28, 'AJ&K IT Board', 1, '2005-08-01 00:00:00', '2005-10-31 00:00:00', NULL, NULL),
(23, 7, 13, 'Punjab University Law College Lahore', 2, '2012-01-01 00:00:00', '2013-01-01 00:00:00', NULL, NULL),
(24, 14, 29, 'Board of Technical Education Peshawar', 2, NULL, NULL, NULL, NULL),
(25, 14, 30, 'CISCO', 2, NULL, NULL, NULL, NULL),
(26, 28, 31, 'AJK University', 1, '2001-01-01 00:00:00', '2001-12-31 00:00:00', NULL, NULL),
(27, 27, 31, 'Govt. FC College Lahore', 2, '2001-01-01 00:00:00', '2001-12-31 00:00:00', NULL, NULL),
(28, 45, 31, 'AIOU', 2, '2003-01-01 00:00:00', '2003-12-31 00:00:00', NULL, NULL),
(29, 45, 14, 'FBR LTO Islamabad', 2, NULL, NULL, NULL, NULL),
(30, 156, 25, 'Iqra University Islamabad', 2, NULL, NULL, NULL, NULL),
(31, 138, 25, NULL, NULL, NULL, NULL, NULL, NULL),
(32, 139, 29, 'Miconic System Gulshan-e-Iqbal Karachi', 2, '1999-03-01 00:00:00', '2000-03-01 00:00:00', NULL, NULL),
(33, 139, 32, 'IZONE, Shahr-e-Faisal Karachi', 2, '2000-06-01 00:00:00', '2001-06-01 00:00:00', NULL, NULL),
(34, 139, 25, 'ICT, The Institute of Computer Technology Karachi', 2, '1998-02-01 00:00:00', '1998-10-01 00:00:00', NULL, NULL),
(35, 253, 25, 'National Institute of IT Neelum Campus', 1, '2008-06-01 00:00:00', '2008-11-01 00:00:00', NULL, NULL),
(36, 139, 29, 'Micronics System (Total IT Solution) Karachi.', 2, '1999-03-01 00:00:00', '2000-02-01 00:00:00', NULL, NULL),
(37, 139, 32, 'Izone, Institute of Comp. Tech., Ghlshan Iqbal,Khi', 2, '2000-06-01 00:00:00', '2001-10-01 00:00:00', NULL, NULL),
(38, 139, 33, 'Institute of Comp. Tech. (ICT), Gulshan Iqbal, Khi', 2, '1998-02-01 00:00:00', '1998-10-01 00:00:00', NULL, NULL),
(42, 22, 24, 'Collectorate of Sales Tax Mirpur', 1, NULL, NULL, NULL, NULL),
(43, 80, 24, 'Shaheen Model, Shakargarh, Narowal', 2, NULL, NULL, NULL, NULL),
(45, 24, 29, 'Muzaffarabad', 2, '1997-06-01 00:00:00', '1998-06-01 00:00:00', NULL, NULL),
(47, 55, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(48, 78, 13, 'Lahore', 2, '2010-01-01 00:00:00', '2011-01-01 00:00:00', NULL, NULL),
(49, 134, 26, NULL, NULL, NULL, NULL, NULL, NULL),
(50, 65, 26, NULL, NULL, NULL, NULL, NULL, NULL),
(51, 158, 26, 'Abbottabad', 2, '2002-02-01 00:00:00', '2002-05-01 00:00:00', NULL, NULL),
(52, 226, 14, NULL, NULL, NULL, NULL, NULL, NULL),
(53, 23, 29, 'Punjab Technical Board, Lahore', 2, '1999-08-01 00:00:00', '2000-08-01 00:00:00', NULL, NULL),
(54, 23, 35, 'Pakistan Computer Bureau, Islamabad', 2, '2013-10-01 00:00:00', '2013-10-31 00:00:00', NULL, NULL),
(55, 50, 36, 'Law Collge, Punjab Univ. Lahore.', 2, '2014-01-06 00:00:00', '2015-03-05 00:00:00', NULL, NULL),
(56, 96, 33, 'Kalri Computers, Mirpur', 2, '2004-02-01 00:00:00', '2004-07-30 00:00:00', NULL, NULL),
(57, 67, 18, 'National Training Board, Skill Development Council', 2, '2004-04-08 00:00:00', '2004-05-08 00:00:00', NULL, NULL),
(58, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
