
-- --------------------------------------------------------

--
-- Table structure for table `qual_framework`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
-- Last check: Aug 01, 2026 at 12:19 AM
--

DROP TABLE IF EXISTS `qual_framework`;
CREATE TABLE `qual_framework` (
  `QFID` int(11) NOT NULL,
  `QFLNo` int(11) DEFAULT 0,
  `QFType` varchar(100) DEFAULT NULL,
  `QFExample` varchar(255) DEFAULT NULL,
  `QYears` varchar(100) DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `qual_framework`:
--

--
-- Dumping data for table `qual_framework`
--

INSERT INTO `qual_framework` (`QFID`, `QFLNo`, `QFType`, `QFExample`, `QYears`) VALUES
(1, 1, 'Primary', 'Pre-School, Primary', '1-5'),
(2, 2, 'Middle', 'Edu. till 8th Class or Equavalent', '5-8'),
(3, 3, 'Matriculation', 'Matric, O-Level etc', '9-10'),
(4, 4, 'Intermediate', 'F.A, FSc, ICS, A-Level, I.Com, DBA, D.Com etc', '11-12'),
(5, 5, 'Associate Ordinary Bachelor', 'B.A, BSc (Pass), ADE, Associate Degree etc', '13-14'),
(6, 6, 'Bachelor', 'BS, BE, B.Arch, BSc(Eng), BSc(Agri), MA/ MSc(16Yrs), LLB, BCom(Hons), MBBA, DVM, PharmD, etc', '15-16'),
(7, 7, 'Masters', 'M.Phil/MS/MBA, MSc(Eng.), ME, M.Arch etc', '17-18'),
(8, 8, 'Doctoral', 'PhD', '19-21');
