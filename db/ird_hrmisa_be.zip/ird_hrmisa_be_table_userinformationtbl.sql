
-- --------------------------------------------------------

--
-- Table structure for table `userinformationtbl`
--
-- Creation: Aug 02, 2026 at 01:20 AM
-- Last update: Aug 02, 2026 at 02:29 AM
--

DROP TABLE IF EXISTS `userinformationtbl`;
CREATE TABLE `userinformationtbl` (
  `UID` int(11) NOT NULL,
  `FirstName` varchar(35) DEFAULT NULL,
  `LastName` varchar(35) DEFAULT NULL,
  `Email` longtext DEFAULT NULL,
  `Cell` varchar(12) DEFAULT NULL,
  `Position` int(11) DEFAULT NULL,
  `UserName` varchar(20) DEFAULT NULL,
  `Password` varchar(30) DEFAULT NULL,
  `UserRoleId` int(11) DEFAULT NULL,
  `StatusId` int(11) DEFAULT NULL,
  `LastAccessDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `CircOffi` int(11) DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `userinformationtbl`:
--   `CircOffi`
--       `circlesoffices` -> `COID`
--   `Position`
--       `designations` -> `DID`
--   `UserRoleId`
--       `userroletbl` -> `UserRoleId`
--

--
-- Dumping data for table `userinformationtbl`
--

INSERT INTO `userinformationtbl` (`UID`, `FirstName`, `LastName`, `Email`, `Cell`, `Position`, `UserName`, `Password`, `UserRoleId`, `StatusId`, `LastAccessDate`, `CircOffi`) VALUES
(2, 'Shahid', 'Rathore', 'rathore@hotmail.com#mailto:rathore@hotmail.com#', '03335145779', NULL, 'shahid', 'shahid', 6, 1, '2026-05-20 08:28:28', NULL),
(3, 'Admin', 'Admin', NULL, NULL, NULL, 'admin', 'root', 2, 1, '2026-05-18 09:38:45', NULL),
(4, 'User', 'User', NULL, NULL, NULL, 'user@gmail.com', 'user', 1, 1, '2026-01-22 06:28:07', NULL),
(5, 'Basil', 'Siddique', NULL, NULL, NULL, 'basil', 'basil', 6, 1, '2026-05-03 04:19:42', NULL),
(6, 'Ghulam', 'Ali', NULL, NULL, NULL, 'ali', 'ali1234', 3, 1, '2026-04-06 05:09:58', NULL),
(8, 'Muhammad', 'Ashraf', NULL, NULL, NULL, 'ashraf', 'ashraf', 4, 2, '2026-02-03 06:30:51', NULL),
(9, 'Muhammad', 'Ishtiaq', 'Ishtiaq@gmail.com', '', NULL, 'Ishtiaq@gmail.com', 'ishtiaq', 1, 1, '2026-08-02 02:29:23', 27);
