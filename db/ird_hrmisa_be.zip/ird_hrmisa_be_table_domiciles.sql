
-- --------------------------------------------------------

--
-- Table structure for table `domiciles`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
-- Last check: Aug 01, 2026 at 12:19 AM
--

DROP TABLE IF EXISTS `domiciles`;
CREATE TABLE `domiciles` (
  `CID` int(11) NOT NULL,
  `CName` varchar(100) DEFAULT NULL,
  `CoName` int(11) DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `domiciles`:
--   `CoName`
--       `countries` -> `CoID`
--

--
-- Dumping data for table `domiciles`
--

INSERT INTO `domiciles` (`CID`, `CName`, `CoName`) VALUES
(1, 'Muzaffarabad', 1),
(2, 'Mirpur', 1),
(3, 'Bhimber', 1),
(4, 'Kotli', 1),
(5, 'Bagh', 1),
(6, 'Rawalakot', 1),
(7, 'Pallandri', 1),
(8, 'Islamabad', 2),
(9, 'Dera Ismail Khan', 2),
(10, 'Neelum', 1),
(11, 'Sudhnoti', 1),
(12, 'Rawalpindi', 2),
(13, 'Jhelum Valley', 1),
(14, 'Poonch', 1),
(15, 'Jehlum', 2),
(16, 'Narowal', 2),
(17, 'Haveli', 1),
(18, 'Refugees', 2),
(19, 'Sialkot', 2);
