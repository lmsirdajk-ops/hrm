
-- --------------------------------------------------------

--
-- Table structure for table `performance`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
--

DROP TABLE IF EXISTS `performance`;
CREATE TABLE `performance` (
  `PerfID` int(11) NOT NULL,
  `PerEmpID` int(11) DEFAULT NULL,
  `TaskAssgn` varchar(200) DEFAULT NULL,
  `TaskDt` datetime DEFAULT NULL,
  `Efficiency` int(11) DEFAULT NULL,
  `Quality` int(11) DEFAULT NULL,
  `Discipline` int(11) DEFAULT NULL,
  `Integrity` int(11) DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `performance`:
--   `PerEmpID`
--       `employees` -> `eid`
--
