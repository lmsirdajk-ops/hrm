
-- --------------------------------------------------------

--
-- Table structure for table `disciplinehistory`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
--

DROP TABLE IF EXISTS `disciplinehistory`;
CREATE TABLE `disciplinehistory` (
  `DSID` int(11) NOT NULL,
  `DS_EMP_ID` int(11) NOT NULL,
  `DS_Details` varchar(255) DEFAULT NULL,
  `DS_Date` datetime DEFAULT NULL,
  `DS_ReportOffr` int(11) DEFAULT NULL,
  `DS_Action` varchar(100) DEFAULT NULL,
  `DS_Decision` varchar(255) DEFAULT NULL,
  `DS_RecomFutureAction` varchar(255) DEFAULT NULL,
  `DS_RecFuturActionComp` varchar(10) DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `disciplinehistory`:
--   `DS_EMP_ID`
--       `employees` -> `eid`
--   `DS_ReportOffr`
--       `employees` -> `eid`
--
