
-- --------------------------------------------------------

--
-- Table structure for table `qual_disciplines`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
-- Last check: Aug 01, 2026 at 12:19 AM
--

DROP TABLE IF EXISTS `qual_disciplines`;
CREATE TABLE `qual_disciplines` (
  `DisID` int(11) NOT NULL,
  `DisName` varchar(100) DEFAULT NULL,
  `Dis_Maj` longtext DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `qual_disciplines`:
--

--
-- Dumping data for table `qual_disciplines`
--

INSERT INTO `qual_disciplines` (`DisID`, `DisName`, `Dis_Maj`) VALUES
(1, 'Legal', 'LLB (4 Yrs) (4Yrs);LLB (5 Yrs) (5Yrs)'),
(2, 'Computer Science/ Info. Technology', 'BS-CS (4Yrs);BS-IT (4Yrs);MCS (2Yrs);MIT (2Yrs);MS-CS (2Yrs);MS-IT (2Yrs);PhD (CS/IT) (5Yrs)'),
(3, 'Business & Management', 'BBA (4Yrs);BB-IT (4Yrs);BCom (2Yrs) (2Yrs);BCom (4Yrs) (4Yrs);MBA  (3.5yrs) (3.5Yrs);MBA (2Yrs) (2Yrs)'),
(4, 'Arts & Humanities', 'BA (2Yrs);BEd (1.5yrs) (1.5Yrs);BEd Hons. (2yrs) (2Yrs);BEd Hons. (4yrs) (4Yrs);M.Phill (Eng.) (2Yrs);MA (2Yrs);MA (Eng.) (2Yrs);MA (Poli-Sci) (2Yrs)'),
(5, 'Natural Sciences', 'BSc (3Yrs);MSc (2Yrs)');
