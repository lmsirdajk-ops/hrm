
-- --------------------------------------------------------

--
-- Table structure for table `qualifications`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
-- Last check: Aug 01, 2026 at 12:10 AM
--

DROP TABLE IF EXISTS `qualifications`;
CREATE TABLE `qualifications` (
  `QID` int(11) NOT NULL,
  `Q_FName` varchar(150) DEFAULT NULL,
  `Q_SName` varchar(20) DEFAULT NULL,
  `Q_Type` varchar(2) DEFAULT NULL,
  `Q_Dur` decimal(18,1) DEFAULT 0.0,
  `Q_Level` int(11) DEFAULT NULL,
  `Q_Disp` int(11) DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `qualifications`:
--   `Q_Disp`
--       `qual_disciplines` -> `DisID`
--   `Q_Level`
--       `qual_framework` -> `QFID`
--

--
-- Dumping data for table `qualifications`
--

INSERT INTO `qualifications` (`QID`, `Q_FName`, `Q_SName`, `Q_Type`, `Q_Dur`, `Q_Level`, `Q_Disp`) VALUES
(1, 'Master of Sciences in Computer Sciences', 'MS-CS', 'd', 2.0, 7, 2),
(2, 'Bachelor of Sciences in Computer Sciences', 'BS-CS', 'd', 4.0, 6, 2),
(3, 'Doctor of Philosophy (Computer Science/ Information Technology)', 'PhD (CS/IT)', 'd', 5.0, 8, 2),
(4, 'Master of Sciences in Information Technology', 'MS-IT', 'd', 2.0, 7, 2),
(5, 'Bachelor of Business Administration', 'BBA', 'd', 4.0, 6, 3),
(6, 'Bachelor of Business & Information Technology', 'BB-IT', 'd', 4.0, 6, 3),
(8, 'Masters in Computer Science', 'MCS', 'd', 2.0, 6, 2),
(9, 'Masters in Information Technology', 'MIT', 'd', 2.0, 6, 2),
(12, 'Matric', 'Matric', 'd', 2.0, 3, NULL),
(15, 'Faculty of Science', 'F.SC', 'd', 2.0, 4, NULL),
(115, 'Diploma in Commerce', 'DCom(2 Yr)', 'dp', 2.0, 5, 3),
(117, 'Bachelor of Arts', 'BA', 'd', 2.0, 5, 4),
(118, 'Post Graduation Diploma in Computer Sciences', 'PGD(1 Yr)', 'dp', 1.0, NULL, NULL),
(119, 'Diploma in Computer Sciences', 'DCS(1 Yr)', 'dp', 1.0, NULL, NULL),
(120, 'Faculty of Arts', 'FA', 'd', 2.0, 4, NULL),
(122, 'Advanced Level', 'A-Level', 'd', 2.0, 4, NULL),
(124, 'Bachelor of Commerce', 'BCom (2Yrs)', 'd', 2.0, 5, 3),
(125, 'Bachelor of Science', 'BSc', 'd', 3.0, 5, NULL),
(127, 'Master of Arts', 'MA', 'd', 2.0, 6, 4),
(130, 'Bachelor of Laws', 'LLB (4 Yrs)', 'd', 4.0, 6, 1),
(131, 'Bachelor of Laws', 'LLB (5 Yrs)', 'd', 5.0, 6, 1),
(133, 'Ordinary Level', 'O-Level', 'd', 2.0, 3, NULL),
(138, 'Bachelor of Sciences in Information Technology', 'BS-IT', 'd', 4.0, 6, 2),
(493, 'Bachelors of Education', 'BEd (1.5yrs)', 'd', 1.5, 5, 4),
(494, 'Bachelors of Education (Hons)', 'BEd Hons. (2yrs)', 'd', 2.0, 5, 4),
(495, 'Bachelors of Education (Hons)', 'BEd Hons. (4yrs)', 'd', 4.0, 6, 4),
(497, 'Master of Business Administration (Exective)', 'MBA  Exec (1.5yrs)', 'dp', 1.5, NULL, NULL),
(498, 'Master of Business Administration', 'MBA  (3.5yrs)', 'd', 3.5, 6, 3),
(499, 'Bachelor of Commerce (4yrs)', 'BCom (4Yrs)', 'd', 4.0, 6, NULL),
(500, 'Master of Science', 'MSc (Comp.)', 'd', 2.0, 6, 2),
(501, 'Master of Business Administration (2yrs)', 'MBA (2Yrs)', 'd', 2.0, 6, NULL),
(502, 'Master of Philosophy (English)', 'M.Phill (Eng.)', 'd', 2.0, 7, NULL),
(503, 'Master of Arts (English)', 'MA (Eng.)', 'd', 2.0, 6, 4),
(504, 'Master of Arts (Political Science)', 'MA (Poli-Sci)', 'd', 2.0, 6, 4),
(505, 'Middle (Till 8th Class)', 'Middle (8th Class)', 'c', 1.0, 2, NULL),
(506, 'Primary (Till 5th Class)', 'Primary (5th Class)', 'c', 1.0, 1, NULL),
(507, 'Master of Science', 'MSc', 'd', 2.0, 6, 5),
(508, 'Master of Commerce', 'M.Com', 'd', 2.0, 6, 3);
