
-- --------------------------------------------------------

--
-- Table structure for table `courses_list`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
-- Last check: Aug 01, 2026 at 12:19 AM
--

DROP TABLE IF EXISTS `courses_list`;
CREATE TABLE `courses_list` (
  `CourID` int(11) NOT NULL,
  `CourNameS` varchar(20) DEFAULT NULL,
  `CourNameL` varchar(255) DEFAULT NULL,
  `Durration` int(11) DEFAULT 0,
  `Durr_Unit` varchar(1) DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `courses_list`:
--

--
-- Dumping data for table `courses_list`
--

INSERT INTO `courses_list` (`CourID`, `CourNameS`, `CourNameL`, `Durration`, `Durr_Unit`) VALUES
(1, 'NMC', 'National Management Course', 18, 'w'),
(2, 'SMC', 'Senior Management Courses', 16, 'w'),
(3, 'PP&MC', 'Professional Planning and Management Course', 12, 'w'),
(4, 'OMC', 'Office Management Course', 0, NULL),
(5, 'SDSTC', 'Specialized Domain Specific Training Course', 0, NULL),
(6, 'OTPPO', 'Orientation Training Programs for Probationer Officers of GoAJK', 0, NULL),
(7, 'TPCM', 'Training Program for Community Mobilizers', 0, NULL),
(8, 'Web Programming', 'Web Programming', 3, 'm'),
(9, 'e-Commerce', 'Electrical Commerce', 8, 'w'),
(10, 'Web Development', 'Website Development', 2, 'm'),
(11, 'Computer Course', 'Computer Course', 2, 'm'),
(12, 'Shorthand & Typing', 'Shorthand & Typing', 3, 'm'),
(13, 'DTL', NULL, 1, 'y'),
(14, 'ITax Ref. Prg', 'Income Tax Refresher Training Programme', 1, 'w'),
(15, 'Bas.Inves.T', 'Basic Investigation Income Tax', 4, 'd'),
(16, 'Bas. Inves. Tx', 'Basic Investigaion Tax (04 days)', 4, 'd'),
(17, 'Crift. Acctt. IT', 'Carlifted Accountant Income Tax', 30, 'm'),
(18, 'Acctt. S.Tx. IT', 'Accountant Sales Tax Income Tax', 30, 'm'),
(19, '38Th Comm. Trn.Prog', '38th Commosn Training Program', 180, 'm'),
(20, '38th (STP) Spec. Tra', '38th (STP) (Specialized Training)', 7, 'm'),
(21, 'MCMC', 'Mid-Career Management Course', 14, 'w'),
(22, 'Fire Prevention', 'Fire Prevention', 2, 'w'),
(23, 'House Hold Appl', 'House Hold Appliances', 1, 'm'),
(24, 'Basic Computer', 'Basic Computer Concepts', 1, 'm'),
(25, 'Computer Course', 'Basic Computer Course', 6, 'm'),
(26, 'Computer Course', 'Computer Course Basic', 3, 'm'),
(27, 'Leadership Course', 'Leadership Course', 1, 'm'),
(28, 'Elementary IT Tr', 'Elementary IT Training Program', 5, 'd'),
(29, 'DCS', 'Diploma In Computer Sciences', 1, 'y'),
(30, 'CCNA', 'CISCO Certified Network Assistant', 3, 'm'),
(31, 'PGD', 'Post Graduate Diploma (Computer Sciences)', 1, 'y'),
(32, 'DIT', 'Diploma In Information Technology', 1, 'y'),
(33, 'Computer Certificate', 'Computer Certificate Course', 6, 'm'),
(34, 'MURS', 'Siemens', 6, 'm'),
(35, 'WD', 'Web Designing', 1, 'm'),
(36, 'PGD (Tax. Laws)', 'Post Graduate Diploma in Taxation Laws', 1, 'y');
