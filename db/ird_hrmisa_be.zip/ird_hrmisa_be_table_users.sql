
-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Creation: Aug 02, 2026 at 02:12 AM
-- Last update: Aug 02, 2026 at 02:29 AM
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(128) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `Cell` varchar(12) DEFAULT NULL,
  `Position` int(11) DEFAULT NULL,
  `UserName` varchar(20) DEFAULT NULL,
  `UserRoleId` int(11) DEFAULT NULL,
  `StatusId` int(11) DEFAULT NULL,
  `LastAccessDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `CircOffi` int(11) DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `users`:
--

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password`, `Cell`, `Position`, `UserName`, `UserRoleId`, `StatusId`, `LastAccessDate`, `CircOffi`) VALUES
(4, 'AJKCBR HRM', 'ajkcbr.hrm@gmail.com', '$2y$10$fo5oDY27jU8lQ4cGwbNikOvttC0SGWyoJeFz/ssin0rtuJHw6Tauy', NULL, NULL, NULL, 2, NULL, '2026-07-14 17:07:33', NULL),
(5, 'Shahid Hussain Rathore', 'rathore@hotmail.com', '$2y$10$mC40OrBo/BFMtUJxlU994.GJddeSZcUOADyv7ZlLq6PmHEhmyPefC', NULL, NULL, NULL, 6, NULL, '2026-07-14 17:07:33', NULL),
(0, 'Muhammad Ishtiaq', 'Ishtiaq@gmail.com', '$2y$10$yZs36xoKfEhEhQsV5V3OtO7tkj3gfnaMEhVRKRrhPvIxO5Mczlfdy', '', NULL, 'Ishtiaq@gmail.com', 1, 1, '2026-08-02 02:29:23', 27);
