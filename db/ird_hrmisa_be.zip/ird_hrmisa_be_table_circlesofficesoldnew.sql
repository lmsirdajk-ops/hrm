
-- --------------------------------------------------------

--
-- Table structure for table `circlesofficesoldnew`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
-- Last check: Aug 01, 2026 at 12:19 AM
--

DROP TABLE IF EXISTS `circlesofficesoldnew`;
CREATE TABLE `circlesofficesoldnew` (
  `COID` int(11) NOT NULL,
  `COName` varchar(60) DEFAULT NULL,
  `COName BM` varchar(255) DEFAULT NULL,
  `CORangID` int(11) DEFAULT NULL,
  `COAdd` varchar(250) DEFAULT 'Nil',
  `COCity` int(11) DEFAULT NULL,
  `COPhLand` varchar(12) DEFAULT NULL,
  `COPhLand2` varchar(12) DEFAULT NULL,
  `COOffCell` varchar(16) DEFAULT NULL,
  `COIncharge` varchar(60) DEFAULT NULL,
  `COInchDesignID` int(11) DEFAULT NULL,
  `COInchCell` varchar(16) DEFAULT NULL,
  `CoInchEmail` varchar(90) DEFAULT NULL,
  `COEmail` varchar(90) DEFAULT NULL,
  `COSortOrd` int(11) DEFAULT 0
) ;

--
-- RELATIONSHIPS FOR TABLE `circlesofficesoldnew`:
--

--
-- Dumping data for table `circlesofficesoldnew`
--

INSERT INTO `circlesofficesoldnew` (`COID`, `COName`, `COName BM`, `CORangID`, `COAdd`, `COCity`, `COPhLand`, `COPhLand2`, `COOffCell`, `COIncharge`, `COInchDesignID`, `COInchCell`, `CoInchEmail`, `COEmail`, `COSortOrd`) VALUES
(1, 'Chairman, CBR Office', 'CBR AJK-Staff', 29, 'House 232, Upper Chatter', 1, NULL, NULL, NULL, 'Mr. Muhammad Raqeeb Khan', 9, '0335-5522552', 'chairmancbr@gmail.com', NULL, 1),
(2, 'Secretary IRD Office', NULL, 29, 'House 232, Upper Chatter', 1, NULL, NULL, NULL, 'Mr. Muhammad Raqeeb Khan', 9, '0335-5522552', 'chairmancbr@gmail.com', NULL, 2),
(3, 'IRD Secretariat', NULL, 29, '\"C\" Block, Services Secretariat', 1, NULL, NULL, NULL, 'Mr. Usman', 6, '0345-2252536', 'Usman@gmail.com', NULL, 3),
(4, 'Circle 1', 'Revenue Circle-01 MZD-Staff', 3, 'Nil', 1, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 8),
(5, 'Circle 2', 'Inland Revenue Circle-02 Mirpur-Staff', 4, 'Nil', 2, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 9),
(6, 'Circle 3', 'Inland Revenue Circle-03 Kotli-Staff', 2, 'Nil', 4, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 10),
(7, 'Circle 4', 'Inland Revenue Circle-04, Rawalakot-Staff', 1, 'Nil', 6, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 11),
(8, 'Circle 5', NULL, 1, 'Nil', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 12),
(9, 'Circle 6', NULL, 3, 'Nil', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 13),
(10, 'Circle 7', 'Inland Revenue Circle-07,(Salary), Mirpur-Staff', 4, 'Nil', 2, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 14),
(11, 'Circle 8', 'Inland Revenue Circle-08, Bhimber-Staff', 2, 'Nil', 3, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 15),
(12, 'Circle 9', NULL, 1, 'Nil', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 16),
(13, 'Circle 10', 'Inland Revenue Circle-10 (Professional), Muzaffarabad', 3, 'Nil', 1, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 17),
(14, 'Circle 11', 'Inland Revenue Circle-11, (Business), Mirpur-Staff', 4, 'Nil', 2, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 18),
(15, 'Circle 12', 'Inland Revenue Circle-12, (Professional),  Mirpur-Staff', 4, 'Nil', 2, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 19),
(16, 'Circle 13', NULL, 4, 'Nil', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 20),
(17, 'Circle 14', 'Circle-14(WHT)MZD-Staff', 3, 'Nil', 1, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 21),
(18, 'Circle 15', NULL, 3, 'Nil', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 22),
(19, 'Circle 16', NULL, 4, 'Nil', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 23),
(21, 'CIR (North), Head Office, Mhz', 'Commissioner IR HO MZD-Staff', 29, 'Texation Department, Near Darbar Saheli Sarkar, Muzaffarabad,\r\nAJK (13100).', 1, '05822-921145', NULL, NULL, 'Mr. Ishtiaq Ahmed', 16, NULL, NULL, NULL, 4),
(22, 'Commissioner IR (South), Mirpur', 'Commissioner Inland Revenue (South Zone)-Staff', 29, 'Srailen Road, New Mirpur City, Azad Jammu and Kashmir (10250)', 2, '05827-927307', NULL, NULL, 'Syed Anser Ali', 18, NULL, NULL, NULL, 5),
(23, 'Central Excise & Sales Tax Audit & Preventive Br.', 'Central Excise & Sales Tax Audit & Preventive Branch, Muzaffarabad-Staff', 29, 'Nil', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 7),
(24, 'Excise Circle, Mirpur', 'Office of Inland Revenue Excise Circle, Mirpur', 4, 'Nil', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6),
(25, 'Muzafferabad Circle', NULL, 29, 'Nil', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0);
