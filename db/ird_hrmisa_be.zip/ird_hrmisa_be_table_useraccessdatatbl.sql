
-- --------------------------------------------------------

--
-- Table structure for table `useraccessdatatbl`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Aug 02, 2026 at 02:29 AM
-- Last check: Aug 01, 2026 at 12:19 AM
--

DROP TABLE IF EXISTS `useraccessdatatbl`;
CREATE TABLE `useraccessdatatbl` (
  `UsrAccID` int(11) NOT NULL,
  `UsrAccUID` int(11) DEFAULT NULL,
  `UsrAccArea` int(11) DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `useraccessdatatbl`:
--   `UsrAccArea`
--       `circlesoffices` -> `COID`
--   `UsrAccUID`
--       `users` -> `id`
--

--
-- Dumping data for table `useraccessdatatbl`
--

INSERT INTO `useraccessdatatbl` (`UsrAccID`, `UsrAccUID`, `UsrAccArea`) VALUES
(1, 5, 4),
(2, 5, 5),
(3, 5, 6),
(4, 5, 7),
(5, 5, 8),
(6, 5, 9),
(7, 5, 10),
(8, 5, 11),
(9, 5, 12),
(10, 5, 13),
(11, 5, 14),
(12, 5, 15),
(13, 5, 16),
(14, 5, 17),
(15, 5, 18),
(16, 5, 19),
(17, 5, 21),
(18, 5, 22),
(19, 5, 31),
(20, 5, 24),
(21, 5, 23),
(22, 5, 53),
(23, 5, 52),
(24, 5, 72),
(25, 5, 29),
(26, 5, 42),
(27, 5, 30),
(28, 5, 49),
(29, 5, 51),
(30, 4, 14),
(31, 9, 27);
