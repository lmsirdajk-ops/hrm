
-- --------------------------------------------------------

--
-- Table structure for table `fin_benifits`
--
-- Creation: Jul 14, 2026 at 05:07 PM
-- Last update: Jul 14, 2026 at 05:07 PM
--

DROP TABLE IF EXISTS `fin_benifits`;
CREATE TABLE `fin_benifits` (
  `FBID` int(11) NOT NULL,
  `FBName` int(11) DEFAULT NULL,
  `FBEID` int(11) DEFAULT NULL,
  `FBAmount` decimal(19,4) DEFAULT 0.0000,
  `FBNotifNo` varchar(150) DEFAULT NULL,
  `FBIssueDate` datetime DEFAULT NULL,
  `FBNoofInstallments` int(11) DEFAULT 0
) ;

--
-- RELATIONSHIPS FOR TABLE `fin_benifits`:
--   `FBEID`
--       `employees` -> `eid`
--
